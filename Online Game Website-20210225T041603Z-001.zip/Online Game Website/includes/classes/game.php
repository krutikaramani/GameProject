<?php

class gamelib {

  function change_priority($to, $id, $auth)
  {
    $query = $auth->datab->query("update nes_player set priority='$to' where userid = '$id'");
  }

  function delete_player($userid, $auth)
  {
    list ($teamnum, $priority, $p, $p) = $this->player_retrieve($userid, $auth);

    $qa = $auth->datab->query("delete from nes_player where userid = '$userid'");

    list ($r, $r, $r, $r, $r, $r, $pr, $r, $count, $r) = $this->team_retrieve($teamnum, $auth);

    $tcoun = $count;
    while($tcoun > $priority)
    {
      list($id, $p, $p) = $this->get_team_member($teamnum, $tcoun, $auth);
      $p = $tcoun - 1;
      $this->change_priority($p, $id, $auth);
      $tcoun = $tcoun - 1;
    }
    list ($r, $r, $r, $r, $r, $r, $r, $r, $count, $r) = $this->team_retrieve($teamnum, $auth);
    $m = $count - 1;
    if ($priority > $m)
    {
      $priority = $priority - 1;
      if ($priority < 1)
        $priority = 1;
    }
    $qb = $this->team_update($teamnum, $m, $p, $auth);
  }
  
  function get_empty_position($auth)
  {
    list ($g, $g, $a_team, $a_team_members, $team_members, $g, $g) = $this->options_retrieve($auth);
    
    $count = $a_team;
    $priority = "0";
    $teamnum = "0";
    $newteam = FALSE;
    while($count > 0)
    {
      list ($t, $t, $t, $t, $t, $t, $t, $t, $members, $t) = $this->team_retrieve($count, $auth);
      if ($members < $team_members)
      {
        $priority = $members + 1;
        $teamnum = $count;
        break;
      }
      $count = $count - 1;
    }
    if ($priority == "0")
    {
      $priority = $a_team_members + 1;
      if ($priority > $team_members)
      {
        $newteam = TRUE;
        $priority = 1;
        $teamnum = $a_team + 1;
      }
    }
    return array($teamnum, $priority, $newteam);
  }
  
  function get_team_count($auth)
  {
    $query = $auth->datab->query("select a_team from nes_game_options");
    list ($a_team) = $auth->datab->fetch_row($query);
    return $a_team;
  }

  function get_team_member($teamnum,$priority,$auth)
  {
    $query = $auth->datab->query("select userid,posts,chars from nes_player where teamnum='$teamnum' and priority='$priority'");
    list($id, $posts, $chars) = $auth->datab->fetch_row($query);
    $result = $auth->datab->num_rows($query);
    return array($id, $posts, $chars);
  }

  function update_player($id, $nchars, $auth)
  {
    $query = $auth->datab->query("select posts,chars from nes_player where userid='$id'");
    list($posts,$chars) = $auth->datab->fetch_row($query);

    $posts = $posts + 1;
    $chars = $chars + $nchars;
    $query = $auth->datab->query("update nes_player set posts='$posts',chars='$chars' where userid='$id'");

    return $query;
  }

  function post_story ($teamnum, $story_continue, $auth)
  {
    if (!$teamnum || !$story_continue)
    {
      return false;
    }
    else
    {
      $query = $auth->datab->query("select members,story,posts,bold,last_post1,last_post2,last_post3,last_post4,last_post5,priority from nes_team_data where team_number = '$teamnum'");
      if ($query < 1)
      {
        return false;
      }
      else
      {
        list ($members, $story, $posts, $bold, $last_post1, $last_post2, $last_post3, $last_post4, $last_post5, $priority) = $auth->datab->fetch_row($query);

        $posts = $posts + 1;
        if ($bold)
        {
          $b = "<B>";
          $b .= $story_continue;
          $b .= "</B><br>";
          $bold = '0';
        }
        else
        {
          $b = $story_continue;
          $b .= "<br>";
          $bold = 1;
        }

        $story .= $b;
        $last_post5 = $last_post4;
        $last_post4 = $last_post3;
        $last_post3 = $last_post2;
        $last_post2 = $last_post1;
        $last_post1 = $story_continue;

        $priority = $priority + 1;
        if ($priority > $members)
          $priority = 1;

        $query = $auth->datab->query("update nes_team_data set priority='$priority',story='$story',last_post1='$last_post1',last_post2='$last_post2',last_post3='$last_post3',last_post4='$last_post4',last_post5='$last_post5',bold='$bold',posts='$posts' where team_number='$teamnum'");

        return $query;
      }
    }
  }

  function game_update ($a_team, $a_team_members, $auth)
  {
    $query = $auth->datab->query("update nes_game_options set (a_team_members='$a_team_members', a_team='$a_team')");
    return $query;
  }

  function team_update ($t, $m, $p, $auth)
  {
    if ($p == "")
    {
      $query = $auth->datab->query("update nes_team_data set (members='$m') where (team_number='$t')");
    }
    else
    {
      $query = $auth->datab->query("update nes_team_data set (members='$m', priority='$p') where (team_number='$t')");
    }
    return $query;
  }

  function player_create($hash, $teamnum,$priority,$auth)
  {
    $query = $auth->datab->query("insert into nes_player (userid,teamnum,priority) VALUES ('$hash', '$teamnum','$priority')");
    return $query;
  }

  function team_create ($teamnum, $story, $auth)
  {
    $query = $auth->datab->query("insert into nes_team_data (team_number,story,priority,members,last_post1) VALUES ('$teamnum','$story','1','0','$story')");
    return $query;
  }

  function team_retrieve ($id, $auth)
  {
    $query = mysql_query("select team_number,last_post1,last_post2,last_post3,last_post4,last_post5,priority,story,members,posts from nes_team_data where team_number = '$id'");

    list ($team_number, $last_post1, $last_post2, $last_post3, $last_post4, $last_post5, $priority, $story,$members,$posts) = $auth->datab->fetch_row($query);

    return array($team_number, $last_post1, $last_post2, $last_post3, $last_post4, $last_post5, $priority, $story, $members,$posts);
  }

  function options_retrieve ($auth)
  {
    $query = $auth->datab->query("select max_chars, min_chars, a_team, a_team_members, team_members, allow_login, starting_sentence from nes_game_options");
    list ($max_chars, $min_chars, $a_team, $a_team_members, $team_members, $allow_login, $starting_sentence) = $auth->datab->fetch_row($query);
    return array($max_chars, $min_chars, $a_team, $a_team_members, $team_members, $allow_login, $starting_sentence);
  }

  function player_retrieve($id, $auth)
  {
    $query = $auth->datab->query("select teamnum,priority,posts,chars from nes_player where userid='$id'");
    list ($teamnum, $priority, $posts, $chars) = $auth->datab->fetch_row($query);
    return array($teamnum, $priority, $posts, $chars);
  }
}

$gamelib = new gamelib;

?>
